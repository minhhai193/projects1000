$(".regular.home-slider.multi-view-slider").slick({
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 1
});

$(".regular.one-view-slider").slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1
});

$(".regular.product-slider.multi-view-slider").slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1
});